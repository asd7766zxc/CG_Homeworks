#pragma once
#include "Animated.hpp"
class DrawObject : public Animated{
public:
	//Always remeber to shift to world x world y
	virtual void Draw(int x, int y) {}
};